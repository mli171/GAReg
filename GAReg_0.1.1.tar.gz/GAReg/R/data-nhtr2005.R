#' Northern Hemisphere temperature reconstruction
#'
#' The 2,000-Year Northern Hemisphere Temperature Reconstruction dataset
#' (Moberg et al., 2005) provides annual temperature anomalies for the
#' Northern Hemisphere from AD 1 to 1979, relative to the 1961–1990 mean.
#' The reconstruction combines high-resolution proxy data (e.g., tree rings)
#' with low-resolution proxies (e.g., sediments) using a wavelet-based method
#' to capture variability across multiple time scales.
#'
#' @format A data frame with 2 variables:
#' \describe{
#'   \item{Year}{Year AD}
#'   \item{Temp}{Temperature anomaly relative to the 1961--1990 mean}
#' }
#' @source Moberg A, Sonechkin DM, Holmgren K, Datsenko NM, Karlén W.
#'   2,000-Year Northern Hemisphere Temperature Reconstruction. IGBP
#'   PAGES/World Data Center for Paleoclimatology Data Contribution Series
#'   #2005-019. NOAA/NGDC Paleoclimatology Program, Boulder, Colorado, USA.
#'
#' @references Moberg A, Sonechkin DM, Holmgren K, Datsenko NM, Karlén W.
#'   (2005). Highly variable Northern Hemisphere temperatures reconstructed
#'   from low- and high-resolution proxy data. *Nature*, 433(7026), 613--617.
"nhtr2005"
